<template>
  <div class="p-8">
    <h1 class="text-3xl font-bold mb-4">MemeBet</h1>
    <p class="mb-4">به پنل مدیریت خوش آمدید!</p>
    <NuxtLink to="/admin" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
      ورود به پنل مدیریت
    </NuxtLink>
  </div>
</template> 